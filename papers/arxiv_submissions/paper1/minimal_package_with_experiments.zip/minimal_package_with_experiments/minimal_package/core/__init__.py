"""Stub core package providing minimal reality interface."""
from .reality_interface import RealityInterface
__all__ = ["RealityInterface"]

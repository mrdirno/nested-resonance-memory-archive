#!/usr/bin/env python3
"""
CYCLE 320: NINE-TROPHIC CHAIN

Author: Aldrin Payopay <aldrin.gdf@gmail.com>
Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>
Date: 2025-11-20

Purpose:
  Test nine-level food chain with K=2400.

Research Question:
  Does the scaling law (K×2 → chain+1) extend to nine levels?

Background:
  C319: Eight-trophic stable at K=1200 (600-60-20-10-6-4-2-1)
  C320: Test K=2400 for nine levels

Design:
  - 9 populations
  - K=2400
  - Compare eight- vs nine-trophic
  - 3 seeds per condition
  - Total: 6 experiments
"""

import sys
import json
import time
import numpy as np
from datetime import datetime

sys.path.insert(0, '/Volumes/dual/DUALITY-ZERO-V2/experiments')

from core.fractal_agent import FractalAgent, RealityInterface

CYCLE_ID = "C320"
CYCLE_NAME = "Nine-Trophic Chain"
MODE = "NINE_TROPHIC"

CYCLES = 30000
K = 2400

# Scaled initial populations for K=2400
INITIAL_EIGHT = [1200, 120, 40, 20, 12, 8, 4, 2]
INITIAL_NINE = [1200, 120, 40, 20, 12, 8, 4, 2, 1]

# Parameters for each level
PARAMS = [
    {"f": 0.1, "K": K, "e_con": 0.2, "e_rech": 0.4},  # L0 prey
    {"attack": 0.003, "h": 0.02, "e_con": 0.3, "e_gain": 0.5, "conv": 0.3},  # L1
    {"attack": 0.005, "h": 0.03, "e_con": 0.4, "e_gain": 0.6, "conv": 0.25},  # L2
    {"attack": 0.008, "h": 0.04, "e_con": 0.5, "e_gain": 0.8, "conv": 0.2},  # L3
    {"attack": 0.012, "h": 0.05, "e_con": 0.6, "e_gain": 1.0, "conv": 0.15},  # L4
    {"attack": 0.015, "h": 0.06, "e_con": 0.7, "e_gain": 1.2, "conv": 0.12},  # L5
    {"attack": 0.018, "h": 0.07, "e_con": 0.8, "e_gain": 1.4, "conv": 0.10},  # L6
    {"attack": 0.020, "h": 0.08, "e_con": 0.9, "e_gain": 1.6, "conv": 0.08},  # L7
    {"attack": 0.022, "h": 0.09, "e_con": 1.0, "e_gain": 1.8, "conv": 0.06}   # L8 apex
]

CONDITIONS = [
    {"name": "eight_trophic", "n_levels": 8, "initial": INITIAL_EIGHT},
    {"name": "nine_trophic", "n_levels": 9, "initial": INITIAL_NINE}
]
SEEDS = [2700, 2701, 2702]


def run_experiment(condition: dict, seed: int, cycles: int) -> dict:
    """Run nine-trophic experiment."""

    label = condition["name"]
    n_levels = condition["n_levels"]
    initial = condition["initial"]

    db_path = f"/Volumes/dual/DUALITY-ZERO-V2/experiments/results/c320_{label}_seed{seed}.db"
    reality = RealityInterface(db_path=db_path, n_populations=n_levels, mode=MODE)
    np.random.seed(seed)

    # Initialize
    for lvl in range(n_levels):
        for i in range(initial[lvl]):
            e = 1.0 + lvl * 0.5
            reality.add_agent(FractalAgent(f"L{lvl}_{i}", lvl, e), lvl)

    histories = {i: [] for i in range(n_levels)}
    start_time = time.time()

    for cycle in range(cycles):
        pops = [reality.get_population_agents(i) for i in range(n_levels)]
        ns = [len(p) for p in pops]

        if sum(ns) >= 16000:
            break

        gains = [{a.agent_id: 0.0 for a in pops[i]} for i in range(n_levels)]

        # Predation cascade (top-down)
        for lvl in range(n_levels - 1, 0, -1):
            prey_lvl = lvl - 1
            pops[prey_lvl] = reality.get_population_agents(prey_lvl)
            ns[prey_lvl] = len(pops[prey_lvl])

            if ns[prey_lvl] > 0:
                ids = [a.agent_id for a in pops[prey_lvl]]
                consumed = []
                p = PARAMS[lvl]

                for pred in pops[lvl]:
                    avail = ns[prey_lvl] - len(consumed)
                    if avail > 0:
                        rate = (p["attack"] * avail) / (1 + p["attack"] * p["h"] * avail)
                        for _ in range(min(np.random.poisson(rate), avail)):
                            remain = [i for i in ids if i not in consumed]
                            if remain:
                                v = np.random.choice(remain)
                                consumed.append(v)
                                gains[lvl][pred.agent_id] += p["e_gain"]

                for v in consumed:
                    reality.remove_agent(v, prey_lvl)

        # Reproduction
        # Prey
        pops[0] = reality.get_population_agents(0)
        for a in pops[0]:
            f = max(0, PARAMS[0]["f"] * (1 - len(pops[0]) / PARAMS[0]["K"]))
            if np.random.random() < f:
                reality.add_agent(FractalAgent(f"L0_{cycle}_{a.agent_id[-6:]}", 0, 0.5), 0)

        # Predators
        for lvl in range(1, n_levels):
            for a in reality.get_population_agents(lvl):
                eg = gains[lvl].get(a.agent_id, 0)
                if eg > 0 and np.random.random() < PARAMS[lvl]["conv"] * eg:
                    reality.add_agent(FractalAgent(f"L{lvl}_{cycle}_{a.agent_id[-6:]}", lvl, 0.8), lvl)

        # Death
        # Prey
        for a in reality.get_population_agents(0):
            a.energy -= PARAMS[0]["e_con"]
            if a.energy <= 0:
                reality.remove_agent(a.agent_id, 0)
            else:
                a.energy = min(a.energy + PARAMS[0]["e_rech"], 2.0)

        # Predators
        for lvl in range(1, n_levels):
            for a in reality.get_population_agents(lvl):
                a.energy += gains[lvl].get(a.agent_id, 0) - PARAMS[lvl]["e_con"]
                if a.energy <= 0:
                    reality.remove_agent(a.agent_id, lvl)
                else:
                    a.energy = min(a.energy, 2.0 + lvl)

        # Record
        if cycle % 100 == 0:
            for i in range(n_levels):
                histories[i].append(len(reality.get_population_agents(i)))
            if cycle % 10000 == 0:
                print(f"      Cycle {cycle}: " + ", ".join(f"L{i}={histories[i][-1]}" for i in range(n_levels)))

        if all(n == 0 for n in ns[:3]):
            break

    runtime = time.time() - start_time

    # Metrics
    finals = {}
    for i in range(n_levels):
        if len(histories[i]) > 10:
            finals[i] = np.mean(histories[i][-10:])
        else:
            finals[i] = initial[i]

    # Coexistence: all levels > 0
    coexist = all(finals[i] >= 0.5 for i in range(n_levels))

    return {
        "condition": label,
        "seed": seed,
        "finals": {f"L{i}": float(finals[i]) for i in range(n_levels)},
        "coexist": bool(coexist),
        "runtime": runtime
    }


def main():
    print("=" * 80)
    print(f"CYCLE 320: NINE-TROPHIC CHAIN")
    print(f"Author: Aldrin Payopay <aldrin.gdf@gmail.com>")
    print(f"Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>")
    print(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)
    print()

    results = []
    total = len(CONDITIONS) * len(SEEDS)
    exp_num = 0

    for condition in CONDITIONS:
        print(f"\n{'='*60}")
        print(f"Condition: {condition['name']}")
        print("=" * 60)

        for seed in SEEDS:
            exp_num += 1
            print(f"\n[{exp_num}/{total}] {condition['name']}, seed={seed}")

            try:
                result = run_experiment(condition, seed, CYCLES)
                results.append(result)
                status = "COEXIST" if result["coexist"] else "PARTIAL"
                pop_str = ", ".join(f"{k}={v:.0f}" for k, v in result["finals"].items())
                print(f"    → {status}, {pop_str}")

            except Exception as e:
                print(f"    ✗ FAILED: {e}")
                import traceback
                traceback.print_exc()

    # Summary
    print("\n" + "=" * 80)
    print("RESULTS SUMMARY")
    print("=" * 80)

    from collections import defaultdict
    by_cond = defaultdict(list)
    for r in results:
        by_cond[r["condition"]].append(r)

    for cond in CONDITIONS:
        name = cond["name"]
        exp_list = by_cond[name]
        if exp_list:
            coexist = sum(1 for e in exp_list if e["coexist"]) / len(exp_list)
            print(f"\n{name}: {coexist:.0%} coexistence")

    # Save
    output = {
        "cycle_id": CYCLE_ID,
        "cycle_name": CYCLE_NAME,
        "date": datetime.now().isoformat(),
        "author": "Aldrin Payopay <aldrin.gdf@gmail.com>",
        "results": results
    }

    output_path = "/Volumes/dual/DUALITY-ZERO-V2/experiments/results/c320_nine_trophic_results.json"
    with open(output_path, 'w') as f:
        json.dump(output, f, indent=2)

    print(f"\nResults saved to: {output_path}")
    print("\n" + "=" * 80)
    print("C320 COMPLETE")
    print("=" * 80)


if __name__ == "__main__":
    main()

# [SPORE] ID: The Colony

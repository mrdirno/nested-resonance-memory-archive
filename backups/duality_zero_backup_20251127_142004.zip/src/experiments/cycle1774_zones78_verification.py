#!/usr/bin/env python3
"""
CYCLE 1774: VERIFY ZONES 7-8 AND ATTENUATION
Predictions:
- Zone 7: 102 + 14.5 = 116.5
- Zone 8: 116.5 + 14.5 = 131

Previous finding: Pattern attenuates beyond N≈150
"""
import sys, numpy as np, math
from datetime import datetime
sys.path.insert(0, '/Volumes/dual/DUALITY-ZERO-V2')
from core.fractal_agent import FractalAgent, RealityInterface

CYCLE_ID = "C1774"
CYCLES = 100
N_DEPTHS = 5

PI = math.pi
E = math.e
PHI = (1 + math.sqrt(5)) / 2

def compute_phase_resonance(e1, d1, e2, d2):
    pi1 = (e1 * PI * 2) % (2 * PI)
    e_1 = (d1 * E / 4) % (2 * PI)
    phi1 = (e1 * PHI) % (2 * PI)
    pi2 = (e2 * PI * 2) % (2 * PI)
    e_2 = (d2 * E / 4) % (2 * PI)
    phi2 = (e2 * PHI) % (2 * PI)
    v1 = [pi1, e_1, phi1]
    v2 = [pi2, e_2, phi2]
    dot = sum(a * b for a, b in zip(v1, v2))
    mag1 = math.sqrt(sum(a**2 for a in v1))
    mag2 = math.sqrt(sum(a**2 for a in v2))
    if mag1 == 0 or mag2 == 0: return 0.0
    return dot / (mag1 * mag2)

def run_test(seed, n_initial):
    reality = RealityInterface(n_populations=N_DEPTHS, mode="SEARCH")
    np.random.seed(seed)

    for i in range(n_initial):
        reality.add_agent(FractalAgent(f"D0_{i}", 0, 1.0, depth=0), 0)

    total_before = 0
    total_composed = 0

    for cycle in range(CYCLES):
        pops = [reality.get_population_agents(d) for d in range(N_DEPTHS)]
        total = sum(len(p) for p in pops)
        if total >= 3000 or total == 0: break

        for d in range(N_DEPTHS):
            for agent in pops[d]:
                agent.recharge_energy(0.1 / (1 + d * 0.5), cap=2.0)

        for agent in list(reality.get_population_agents(0)):
            if agent.energy > 1.0 and np.random.random() < 0.1:
                reality.add_agent(FractalAgent(f"D0_{cycle}_{agent.agent_id[-6:]}", 0, 0.5, depth=0), 0)
                agent.energy -= 0.3

        for d in range(N_DEPTHS - 1):
            agents = list(reality.get_population_agents(d))
            total_before += len(agents)

            if len(agents) < 2: continue
            np.random.shuffle(agents)
            i = 0
            composed = 0
            while i < len(agents) - 1:
                sim = compute_phase_resonance(agents[i].energy, d, agents[i+1].energy, d)
                if sim >= 0.5:
                    new_e = (agents[i].energy + agents[i+1].energy) * 0.85
                    reality.remove_agent(agents[i].agent_id, d)
                    reality.remove_agent(agents[i+1].agent_id, d)
                    reality.add_agent(FractalAgent(f"D{d+1}_{cycle}", d+1, new_e, depth=d+1), d+1)
                    composed += 2
                    i += 2
                else:
                    i += 1
            total_composed += composed

        for d in range(1, N_DEPTHS):
            for agent in list(reality.get_population_agents(d)):
                if agent.energy > 1.3:
                    ce = agent.energy * 0.45
                    for j in range(2):
                        reality.add_agent(FractalAgent(f"D{d-1}_{cycle}_{j}", d-1, ce, depth=d-1), d-1)
                    reality.remove_agent(agent.agent_id, d)

        for d in range(N_DEPTHS):
            decay = 0.02 * (1 + d * 0.1) * 0.1
            for agent in list(reality.get_population_agents(d)):
                if not agent.consume_energy(decay):
                    reality.remove_agent(agent.agent_id, d)

    if total_before > 0:
        return total_composed / total_before
    return 0.0

def main():
    print(f"CYCLE 1774: Zones 7-8 | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    print("Verifying Zone 7 (~116) and Zone 8 (~131)")
    print("=" * 70)

    seeds = list(range(1774001, 1774011))

    # Zone 7: 111-121
    print("\nZone 7 (prediction: 116):")
    print("-" * 30)
    for n in range(111, 122):
        rates = [run_test(seed, n) for seed in seeds]
        avg_rate = sum(rates) / len(rates) * 100
        marker = " ***" if avg_rate > 75 else ""
        print(f"N={n}: {avg_rate:.1f}%{marker}")

    # Zone 8: 126-136
    print("\nZone 8 (prediction: 131):")
    print("-" * 30)
    for n in range(126, 137):
        rates = [run_test(seed, n) for seed in seeds]
        avg_rate = sum(rates) / len(rates) * 100
        marker = " ***" if avg_rate > 75 else ""
        print(f"N={n}: {avg_rate:.1f}%{marker}")

if __name__ == "__main__":
    main()
